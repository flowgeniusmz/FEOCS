import streamlit as st
import datetime

def get_certificate_info_FEOCId():
    var = "FEOC02"
    return var

def get_certificate_info_Project():
    var = "Carbon offset reduction for Jet Fuel"
    return var

def get_certificate_info_StartDate():
    var = "01/01/2023"
    return var

def get_certificate_info_EndDate():
    var = "01/01/2030"
    return var

def get_certificate_info_Emitter():
    var = "Bevron Refinery"
    return var

def get_certificate_info_Provider():
    var = "Wizmo Power"
    return var

def get_certificate_info_Purchaser():
    var = "Welta Airlines"
    return var

def get_certificate_info_Credit():
    var = "A"
    return var

