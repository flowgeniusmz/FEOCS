import streamlit as st
from st_login_form import login_form
from supabase import create_client, client

def get_loginform():
    client = login_form("FEOC Authentication", allow_guest=False)

    if st.session_state.authenticated:
        if st.session_state.username:
            st.success(f"Welcome {st.session_state.username}")
        else:
            st.success("Welcome Guest")
    else:
        st.error("Not Authenticated")


def check_authentication():
    """
    Check if the user is authenticated.
    
    Returns:
        bool: True if authenticated, False otherwise.
    """
    if "authenticated" not in st.session_state:
        get_loginform()
        return False
    return True
#https://app.supabase.com/project/rbaawqpeyigwmzukrmvc/editor/28594
#https://docs.streamlit.io/knowledge-base/tutorials/databases/supabase#create-a-supabase-database
