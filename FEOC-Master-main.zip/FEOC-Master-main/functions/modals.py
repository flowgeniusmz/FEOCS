import streamlit as st
from streamlit_modal import Modal
from functions.forms import form_home_demorequest, form_actions_sendemail
from functions.pagesetup import set_page_overview, set_title

def create_modal(button_text, key_prefix, title, form_function):
    modal = Modal("", key=f"{key_prefix}Modal")
    modal_button = st.button(button_text, key=f"{key_prefix}Button", type="primary", use_container_width=True)
    
    if modal_button:
        modal.open()
    
    if modal.is_open():
        with modal.container():
            set_title("FEOC", title)
            modal_content = st.container()
            with modal_content:
                columns = st.columns(2)
                with columns[0]:
                    set_page_overview("Instructions", f"Complete the form to {button_text.lower()}.")
                    st.markdown("#### Contact Information")
                    st.markdown("**Phone Number:** 111-222-3333")
                    st.markdown("**Email:** info@faulkercapital.com")
                with columns[1]:
                    sform = st.form(f"form{title}")
                    with sform:
                        form_submit = form_function()
                        if form_submit:
                            modal.close()

def modal_home_demorequest():
    create_modal("Request Demo", "demoRequest", "Demo Request Form", form_home_demorequest)

def modal_actions_sendemail():
    create_modal("Send Email", "sendEmail", "Send Email Form", form_actions_sendemail)
