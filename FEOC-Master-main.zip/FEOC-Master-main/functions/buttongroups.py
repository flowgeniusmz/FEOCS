import streamlit as st
from st_btn_group import st_btn_group



def btn_grp_pageAI():
    btn_grp = st_btn_group(
        buttons=[
            {"label": '<i class="fas fa-search"></i>Chat-With-Search AI', "value": "1"},
            {"label": '<i class="fas fa-chart-bar"></i>Chat-With-Data AI', "value": "2"},
            {"label": '<i class="fas fa-book"></i>Chat-With-Streamlit', "value": "3"}
        ],
    key = "pageAIbtn")
    return btn_grp
