import streamlit as st
import requests


def requests_send_email(varSender, varName, varEmail, varMessage, varRecipient):

    body = {
        "sender": varSender,
        "name": varName,
        "email": varEmail,
        "message": varMessage,
        "recipient": varRecipient
    }

    url = st.secrets.powerautomate.paSendEmail

    response = requests.post(url=url, json=body)

    return #response
