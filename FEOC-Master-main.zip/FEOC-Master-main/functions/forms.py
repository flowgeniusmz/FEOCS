import streamlit as st
from functions.callbacks import callback_home_form_demorequest, callback_send_email_form
import datetime

def form_home_demorequest():
    sname = st.text_input("Name")
    semail = st.text_input("Email")
    sphone = st.text_input("Phone Number")
    sdate = st.date_input("Desired Date", format="MM/DD/YYYY", min_value=datetime.date(2023, 1, 1))
    demo_form_submit = st.form_submit_button(
        "Submit", 
        type="primary", 
        use_container_width=True, 
        on_click=callback_home_form_demorequest(sname, semail, sphone, sdate)
    )
    return demo_form_submit

def form_actions_sendemail():
    sSender = st.text_input("Sender Name")
    sEmail = st.text_input("Sender Email")
    sName = st.text_input("Recipient Name")
    sRecipient = st.text_input("Recipient Email")
    sMessage = st.text_area("Email Message")

    send_email_form_submit = st.form_submit_button(
        "Submit",
        type="primary",
        use_container_width=True,
        on_click=lambda: callback_send_email_form(sSender, sName, sEmail, sMessage, sRecipient)
    )
    return send_email_form_submit
