import streamlit as st
from functions.requests import requests_send_email

def callback_dataframes(varDF, varDFName):
    if f"{varDFName}" not in st.session_state:
        st.session_state.varDFName = varDF
    st.session_state.varDFName = varDF

def callback_home_form_demorequest(varName, varEmail, varPhone, varDate):
    st.session_state.formDemoName = varName
    st.session_state.formDemoEmail = varEmail
    st.session_state.formDemoPhone = varPhone
    st.session_state.formDemoDate = varDate

def callback_send_email_form(varSender, varName, varEmail, varMessage, varRecipient):
    # Saving values to st.session_state
    st.session_state.sender = varSender
    st.session_state.senderEmail = varEmail
    st.session_state.recipientName = varName
    st.session_state.recipientEmail = varRecipient
    st.session_state.message = varMessage

    # Triggering the email sending request
    response = requests_send_email(varSender, varName, varEmail, varMessage, varRecipient)
    
    if response.status_code == 200:
        st.success("Email sent successfully!")
    else:
        st.error(f"Failed to send email. Error: {response.text}")
