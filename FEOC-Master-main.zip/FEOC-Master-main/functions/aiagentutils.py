import streamlit as st

from langchain.agents import initialize_agent, AgentType
from langchain_experimental.agents.agent_toolkits import  create_pandas_dataframe_agent
from langchain.callbacks import StreamingStdOutCallbackHandler, StreamlitCallbackHandler
from langchain.chat_models import ChatOpenAI
from langchain.tools import DuckDuckGoSearchRun
from llama_index import VectorStoreIndex, ServiceContext, Document
from llama_index.llms import OpenAI
import openai
from llama_index import SimpleDirectoryReader


openai_api_key = st.secrets.OPENAI_API_KEY

# Function to initialize chatbot messages
def initialize_chat(session_key, initial_message):
    if session_key not in st.session_state:
        st.session_state[session_key] = [
            {"role": "assistant", "content": initial_message}
        ]

# Function to display the chat messages
def display_messages(container, session_key):
    for msg in st.session_state[session_key]:
        container.chat_message(msg["role"]).write(msg["content"])

# Function to handle the user prompt and LLM processing
def handle_prompt_and_llm(container, session_key, openai_api_key):
    prompt = container.chat_input(placeholder="Enter your query...")
    
    if prompt:
        st.session_state[session_key].append({"role": "user", "content": prompt})
        display_messages(container, session_key)


       # if not openai_api_key:
        #    st.info("Please add your OpenAI API key to continue.")
         #   st.stop()

        llm = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=openai_api_key, streaming=True)
        search = DuckDuckGoSearchRun(name="Search")
        search_agent = initialize_agent([search], llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, handle_parsing_errors=True)
        
        with container.chat_message("assistant"):
            st_cb = StreamlitCallbackHandler(container.container(), expand_new_thoughts=False)
            response = search_agent.run(st.session_state[session_key], callbacks=[st_cb])
            st.session_state[session_key].append({"role": "assistant", "content": response})
            container.write(response)

def get_langdocs_ai():
    if "messagesDocs" not in st.session_state:
        st.session_state["messagesDocs"] = [
            {"role": "assistant", "content": "Hi, I'm a chatbot who can review docs. How can I help you?"}
        ]
    
    for msg in st.session_state.messagesDocs:
        st.chat_message(msg["role"]).write(msg["content"])
    
    if prompt := st.chat_input(placeholder="What page is this on...?"):
        st.session_state.messagesDocs.append({"role": "user", "content": prompt})
        st.chat_message("user").write(prompt)
    
          
        llm = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=openai_api_key, streaming=True)
        search = DuckDuckGoSearchRun(name="Search")
        search_agent = initialize_agent([search], llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, handle_parsing_errors=True)
        with st.chat_message("assistant"):
            st_cb = StreamlitCallbackHandler(st.container(), expand_new_thoughts=False)
            response = search_agent.run(st.session_state.messagesDocs, callbacks=[st_cb])
            st.session_state.messagesDocs.append({"role": "assistant", "content": response})
            st.write(response)

def get_langpandas_ai(df):
    if "messagesPandas" not in st.session_state:
        st.session_state["messagesPandas"] = [
            {"role": "assistant", "content": "Hi, I'm a chatbot who can analyze data. How can I help you?"}
        ]
    
    for msg in st.session_state.messagesPandas:
        st.chat_message(msg["role"]).write(msg["content"])
    
    if prompt := st.chat_input(placeholder="What insights should i know...?"):
        st.session_state.messagesPandas.append({"role": "user", "content": prompt})
        st.chat_message("user").write(prompt)
    
          
        llm = ChatOpenAI(model_name="gpt-3.5-turbo-0613", openai_api_key=openai_api_key, streaming=True)
        pandas_df_agent = create_pandas_dataframe_agent(llm, df, verbose=True, agent_type=AgentType.OPENAI_FUNCTIONS, handle_parsing_errors=True,)

        with st.chat_message("assistant"):
            st_cb = StreamlitCallbackHandler(st.container(), expand_new_thoughts=False)
            response = pandas_df_agent.run(st.session_state.messagesPandas, callbacks=[st_cb])
            st.session_state.messagesPandas.append({"role": "assistant", "content": response})
            st.write(response)
    

def get_langsearch_ai():

    if "messagesSearch" not in st.session_state:
        st.session_state["messagesSearch"] = [
            {"role": "assistant", "content": "Hi, I'm a chatbot who can search the web. How can I help you?"}
        ]
    
    for msg in st.session_state.messagesSearch:
        st.chat_message(msg["role"]).write(msg["content"])
    
    if prompt := st.chat_input(placeholder="Who won the Women's U.S. Open in 2018?"):
        st.session_state.messagesSearch.append({"role": "user", "content": prompt})
        st.chat_message("user").write(prompt)
    
          
        llm = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=openai_api_key, streaming=True)
        search = DuckDuckGoSearchRun(name="Search")
        search_agent = initialize_agent([search], llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, handle_parsing_errors=True)
        with st.chat_message("assistant"):
            st_cb = StreamlitCallbackHandler(st.container(), expand_new_thoughts=False)
            response = search_agent.run(st.session_state.messagesSearch, callbacks=[st_cb])
            st.session_state.messagesSearch.append({"role": "assistant", "content": response})
            st.write(response)
