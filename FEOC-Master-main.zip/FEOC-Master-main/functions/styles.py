import streamlit as st


def theme_expander_header_content():
    st.markdown('''
            <style>
            .streamlit-expanderHeader {
                background-color: rgba(0, 176, 132, 0.6);
            }
            .streamlit-expanderContent {
                background-color: rgba(0, 176, 132, 0.6);
            }
            </style>
            ''',
            unsafe_allow_html=True
        )

    
def theme_fa_icons():
    st.markdown("""<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">""",unsafe_allow_html=True)
