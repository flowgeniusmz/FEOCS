import streamlit as st
from streamlit_extras.chart_container import chart_container, _get_random_data

def chart_container1():
    chart_data = _get_random_data()
    with chart_container(chart_data):
        st.write(
            "I can use a subset of the data for my chart... "
            "but still give all the necessary context in "
            "`chart_container`!"
        )
        st.area_chart(chart_data[["a", "b"]])
#https://arnaudmiribel.github.io/streamlit-extras/extras/chart_container/

def chart_container2():
    chart_data = _get_random_data()
    with chart_container(chart_data):
        st.write("Here's a cool chart")
        st.area_chart(chart_data)
#https://arnaudmiribel.github.io/streamlit-extras/extras/chart_container/
