import streamlit as st
from streamlit_extras.switch_page_button import switch_page

def switchpage_CentralPerformancePanel():
    btn_central_performance_panel = st.button("Click to view", key="btnCentralPerformancePanel", type="primary", use_container_width=True )
    if btn_central_performance_panel:
        switch_page("Central Performance Panel")

def switchpage_AnalyticsPanel():
    btn_analytics_panel = st.button("Click to view", key="btnAnalyticsPanel", type="primary", use_container_width=True )
    if btn_analytics_panel:
        switch_page("Analytics Panel")
        
def switchpage_ActionsPanel():
    btn_actions_panel = st.button("Click to view", key="btnActionsPanel", type="primary", use_container_width=True )
    if btn_actions_panel:
        switch_page("Actions Panel")

def switchpage_AIPanel():
    btn_ai_panel = st.button("Click to view", key="btnAIPanel", type="primary", use_container_width=True )
    if btn_ai_panel:
        switch_page("AI Panel")

def switchpage_SensorPanel():
    btn_sensor_panel = st.button("Click to view", key="btnSensorPanel", type="primary", use_container_width=True )
    if btn_sensor_panel:
        switch_page("Sensor Panel")
