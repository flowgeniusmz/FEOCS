import streamlit as st
from  functions.login import check_authentication
from functions.pagesetup import set_title, set_page_overview, set_blue_header, set_green_header
from functions.supabase import get_data_notifications
from functions.variables import get_certificate_info_Credit, get_certificate_info_Emitter, get_certificate_info_EndDate, get_certificate_info_FEOCId, get_certificate_info_Project, get_certificate_info_Provider, get_certificate_info_Purchaser, get_certificate_info_StartDate
import pandas as pd
from containers.pageAI import get_ai_tabs
from functions.aiagentutils import get_langsearch_ai, get_langpandas_ai, get_langdocs_ai
from functions.buttongroups import btn_grp_pageAI
from functions.supabase import get_data_audit, get_data_certs, get_data_notifications, get_data_sensors, get_data_users

st.set_page_config(layout="wide", initial_sidebar_state="collapsed")

if check_authentication():
    container0 = st.container()
    with container0:
        set_title("FEOC", "AI Panel")
        set_page_overview("Overview", "**AI Panel** provides the ability for users to engage and interact with the certificate specific AI")
    btns = btn_grp_pageAI()
    if btns =="1":
        get_langsearch_ai()
    elif btns == "2":
        df = get_data_audit()
        get_langpandas_ai(df)
    elif btns == "3":
        get_langdocs_ai()
    else:
        get_langsearch_ai()
        
