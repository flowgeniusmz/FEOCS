import time  # to simulate a real time data, time loop

import numpy as np  # np mean, np random
import pandas as pd  # read csv, df manipulation
import plotly.express as px  # interactive charts
import streamlit as st  # 🎈 data web app development

from functions.pagesetup import set_title_pageoverview
from functions.login import check_authentication
from containers.pageAnalytics import get_analytics_metrics, get_analytics_tabs

st.set_page_config(layout="wide", initial_sidebar_state="collapsed")

if check_authentication:
    set_title_pageoverview("FEOC", "Analytics Panel", "Overview", "The **Analytics Panel** contains real-time operational and financial dashboards to assess overall performance of the FEOC. Use the tabs below to navigate.")
    
    # Load data
    @st.cache
    def load_data():
        return pd.read_csv('data/sequestration_streaming.csv')
    
    df = load_data()
    
    # This function simulates real-time data update
    def get_new_data(row_num):
        return df.iloc[row_num]
    
    # Streaming Simulation
    placeholder = st.empty()
    row_num = 0
    
    while row_num < len(df):
        data_point = get_new_data(row_num)
        
        # KPIs
        col1, col2, col3, col4 = st.columns(4)
        
        col1.metric("CO2 Captured", value=f"{data_point['CO2 Captured']:.2f}")
        col2.metric("Energy Consumption", value=f"{data_point['Energy Consumption']:.2f}")
        col3.metric("Water Usage", value=f"{data_point['Water Usage']:.2f}")
        col4.metric("Land Area Used (hectares)", value=f"{data_point['Land Area Used (hectares)']:.2f}")
        
        # Detailed Data View
        placeholder.dataframe(data_point.to_frame().T)
        
        time.sleep(1)  # Sleep for 1 second to simulate real-time update
        row_num += 1
