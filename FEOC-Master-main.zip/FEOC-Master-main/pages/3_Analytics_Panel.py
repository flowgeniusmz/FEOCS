import streamlit as st
import pandas as pd
from functions.pagesetup import set_title_pageoverview
from functions.login import check_authentication
from containers.pageAnalytics import get_analytics_metrics, get_analytics_tabs

st.set_page_config(layout="wide", initial_sidebar_state="collapsed")

if check_authentication:
    set_title_pageoverview("FEOC", "Analytics Panel", "Overview", "The **Analytics Panel** contains real-time operational and financial dashboards to assess overall performance of the FEOC. Use the tabs below to navigate.")
    container1 = st.container()
    with container1:
        get_analytics_tabs()
