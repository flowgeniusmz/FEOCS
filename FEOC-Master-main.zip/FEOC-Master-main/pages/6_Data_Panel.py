import streamlit as st
from functions.supabase import get_data_audit, get_data_certs, get_data_notifications, get_data_sensors, get_data_users
from functions.login import check_authentication
from functions.pagesetup import set_title_pageoverview
from functions.dataframes import filter_dataframe, get_dataframe

st.set_page_config(layout="wide", initial_sidebar_state="collapsed")

dfAudit1 = get_dataframe(get_data_audit())
dfNotifications1 = get_dataframe(get_data_notifications())
dfCerts1 = get_dataframe(get_data_certs())
dfSensors1 = get_dataframe(get_data_sensors())
dfUsers1 = get_dataframe(get_data_users())

if check_authentication:
    set_title_pageoverview("FEOC", "Data Panel", "Overview", "Certificate data is available on this page. Use the tabs to explore.") 
    tabNotifications, tabAudit, tabUsers, tabSensors, tabCerts = st.tabs(["Notifications", "Audit", "Users", "Sensors", "Certificates"])
    with tabNotifications:
        st.dataframe(dfNotifications1)
    with tabAudit:
        st.write(dfAudit1)
    with tabUsers:
        st.write(dfUsers1)
    with tabSensors:
        st.write(dfSensors1)
    with tabCerts:
        st.write(dfCerts1)
