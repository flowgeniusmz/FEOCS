import streamlit as st
import extra_streamlit_components as stx
from streamlit_extras.metric_cards import style_metric_cards
from functions.pagesetup import get_metric_container, set_blue_header
from functions.charts import chart_container1, chart_container2
from langchain_experimental.agents.agent_toolkits import  create_pandas_dataframe_agent
from langchain.callbacks import StreamingStdOutCallbackHandler
from langchain.chat_models import ChatOpenAI
from functions.aiagentutils import initialize_chat, display_messages, handle_prompt_and_llm
import pandas as pd
import os
from functions.buttongroups import btn_grp_pageAI


openai_api_key = st.secrets.OPENAI_API_KEY

tablistAI = [
            stx.TabBarItemData(id=1, title="Chat-With-Data Agent", description="AI for Certificate Data"), 
            stx.TabBarItemData(id=2, title="Chat-With-Search Agent", description="AI for general inquiries"), 
            stx.TabBarItemData(id=3, title="Chat-with-St.Docs Agent", description="AI for St docs")
]

messagesSearch_initial = [{"role": "assistant", "content": "Hi, I'm a chatbot who can search the web. How can I help you?"}]
messagesPandas_initial = [{"role": "assistant", "content": "Hi, I'm a chatbot who can analyze your data. How can I help you?"}]
messagesStDocs_initial = [{"role": "assistant", "content": "Hi, I'm a chatbot who can interact with streamlit docs. How can I help you?"}]
messagesAll_initialRole = "assistant"

#Append messages function
def update_messages(varMessages, varRole, varContent):
    sMessage = {"role": varRole, "content": varContent}
    varMessages.append(sMessage)
    return varMessages

#Reset messages funciton
def reset_messages(varMessages, name):
    initial_messages = {
        "search": messagesSearch_initial,
        "pandas": messagesPandas_initial,
        "streamlit_docs": messagesStDocs_initial
    }
    
    if name in initial_messages:
        content = initial_messages[name]
        for message in varMessages:
            if message["role"] == "assistant":
                message["content"] = content
                return varMessages

        # If no message with role "assistant" was found, append a new one
        varMessages.append({"role": "assistant", "content": content})
    else:
        print(f"No initial message found for name: {name}")

    return varMessages
    

def get_selected_tab_aiPandas():
    set_blue_header("Chat-With-Data Agent")
    #container = st.container()
    #with container():
    st.warning("Use this `autonomous AI agent` to ask questions about the data associated to this FEOC.")
    st.divider()
    initialize_chat("messagesPandas", messagesPandas_initial)
    display_messages(st, "messagesPandas")
    handle_prompt_and_llm(st, "messagesPandas", openai_api_key, search_type="data")

def get_selected_tab_aiSearch():
    set_blue_header("Chat-With-Search Agent")
    #container = st.container()
   # with container():
    st.warning("Use this `autonomous AI agent` to ask questions about anything")
    st.divider()
    initialize_chat("messagesSearch", messagesSearch_initial)
    display_messages(st, "messagesSearch")
    handle_prompt_and_llm(st, "messagesSearch", openai_api_key, search_type="data")

def get_selected_tab_aiStDocs():
    set_blue_header("Chat-With-StDocs Agent")
    #container = st.container()
   #with container():
    st.warning("Use this `autonomous AI agent` to ask questions about streamlit documents")
    st.divider()
    initialize_chat("messagesStDocs", messagesStDocs_initial)
    display_messages(st, "messagesStDocs")
    handle_prompt_and_llm(st, "messagesStDocs", openai_api_key, search_type="data")       

def get_ai_tabs():
    tab_selected_ai_id = stx.tab_bar(tablistAI, default="1")
    if tab_selected_ai_id == "1":
        get_selected_tab_aiPandas()
    elif tab_selected_ai_id =="2":
        get_selected_tab_aiSearch()
    elif tab_selected_ai_id == "3":
        get_selected_tab_aiStDocs()
    else:
        get_selected_tab_aiPandas()

def btn_grp_selection_pageAI():
    returned = btn_grp_pageAI()
    if returned == "1":
            get_selected_tab_aiPandas()
    elif returned == "2":
            get_selected_tab_aiSearch()
    elif returned == "3":
            get_selected_tab_aiStDocs()
    else:
            get_selected_tab_aiPandas()


#https://smith.langchain.com/hub?organizationId=75d5d2e9-7416-5412-a7ac-6060eeb726af
#https://www.geeksforgeeks.org/create-a-simple-sentiment-analysis-webapp-using-streamlit/
