import streamlit as st
import extra_streamlit_components as stx
from streamlit_extras.metric_cards import style_metric_cards
from functions.pagesetup import get_metric_container, set_blue_header
from functions.forms import form_actions_sendemail

tablistActions = [
    stx.TabBarItemData(id=1, title="Send Communication", description="Send a communication to one or more parties."),
    stx.TabBarItemData(id=2, title="Financial Transaction", description="Initiate a financial transaction."),
    stx.TabBarItemData(id=3, title="User Request", description="Request to add or edit users."),
    stx.TabBarItemData(id=5, title="Audit History", description="View audit history.")
]

def get_selected_tab_sendcomms():
    formSendComms = form_actions_sendemail()
    return formSendComms
def get_selected_tab_fintransact():
    return
def get_selected_tab_userrequest():
    return
def get_selected_tab_audithistory():
    return

def get_actions_tabs():
    tab_selected_actions = stx.tab_bar(tablistActions, default="1")
    if tab_selected_actions=="1":
        get_selected_tab_sendcomms()
    if tab_selected_actions=="2":
        get_selected_tab_fintransact()
    if tab_selected_actions=="3":
        get_selected_tab_userrequest()
    if tab_selected_actions=="4":
        get_selected_tab_audithistory()
    else: 
        get_selected_tab_sendcomms()
    return
