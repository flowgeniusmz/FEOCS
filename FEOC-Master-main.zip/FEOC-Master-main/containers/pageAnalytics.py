import streamlit as st
import extra_streamlit_components as stx
from streamlit_extras.metric_cards import style_metric_cards
from functions.pagesetup import get_metric_container, set_blue_header
from functions.charts import chart_container1, chart_container2
import plotly.express as px
import numpy as np
import pandas as pd
import time


tablist = [
            stx.TabBarItemData(id=11, title="Streaming Dashboard", description="View real-time data and insights"),
            stx.TabBarItemData(id=12, title="Financial Dashboard", description="View real-time data and insights"), 
            stx.TabBarItemData(id=13, title="Operational Dashboard", description="View real-time data and insights")
        ]

metrics_streaming = [
    {"label": "Carbon Reduction Commitment", "id": "metrics1", "value": 1000, "delta": 100},
    {"label": "Net Zero Fuel Sales", "id": "metrics2", "value": 5000, "delta": -100},
    {"label": "Project Financing", "id": "metrics3", "value": 3000, "delta": 0}
]

metrics_financial = [
    {"label": "Carbon Reduction Commitment", "id": "metricf1", "value": 8383, "delta": 100},
    {"label": "Net Zero Fuel Sales", "id": "metricf2", "value": 3534, "delta": -100},
    {"label": "Project Financing", "id": "metricf3", "value": 24335, "delta": 0}
]

metrics_operational = [
    {"label": "Carbon Reduction Commitment", "id": "metrico1", "value": 3242, "delta": 100},
    {"label": "Net Zero Fuel Sales", "id": "metrico2", "value": 5735, "delta": -100},
    {"label": "Project Financing", "id": "metrico3", "value": 4673, "delta": 0}
]



def get_analytics_metrics(varMetrics):
    get_metric_container(varMetrics=varMetrics)

def chart_container1():  # Mockup chart. Replace with actual visualization.
    fig = px.line(np.random.randn(100).cumsum())
    st.plotly_chart(fig)

def chart_container2():  # Mockup chart. Replace with actual visualization.
    fig = px.bar(np.random.randn(100))
    st.plotly_chart(fig)

def get_selected_tab_streaming():
    set_blue_header("Key Metrics")
    container = st.container()
    with container:
        containera = st.container()
        with containera:
            get_analytics_metrics(metrics_streaming)
        
        st.divider()
        
        containerb = st.container()
        with containerb:
            ccb = st.columns(2)
            with ccb[0]:
                chart_container1()
            with ccb[1]:
                chart_container2()
        
        st.divider()
        
        set_blue_header("Charts")
        containerc = st.container()
        with containerc:
            ccc = st.columns(2)
            with ccc[0]:
                chart_container1()
            with ccc[1]: 
                chart_container2()
        
        st.divider()
        set_blue_header("Streaming Data")
        
        # Load data
        @st.cache
        def load_data():
            data = pd.read_csv('data/sequestration_streaming.csv')
            return data.iloc[::-1].reset_index(drop=True)
    
        df = load_data()
    
        # This function simulates real-time data update
        def get_new_data(row_num):
            return df.iloc[row_num]
    
        # Streaming Simulation
        placeholder = st.empty()
        row_num = 0
    
        while row_num < len(df):
            data_point = get_new_data(row_num)
            
            # KPIs
            col1, col2, col3, col4 = st.columns(4)
            
            col1.metric("CO2 Captured", value=f"{data_point['CO2 Captured']:.2f}")
            col2.metric("Energy Consumption", value=f"{data_point['Energy Consumption']:.2f}")
            col3.metric("Water Usage", value=f"{data_point['Water Usage']:.2f}")
            col4.metric("Land Area Used (hectares)", value=f"{data_point['Land Area Used (hectares)']:.2f}")
            
            # Detailed Data View
            placeholder.dataframe(data_point.to_frame().T)
            
            time.sleep(1)  
            row_num += 1

def get_selected_tab_operational():
    set_blue_header("Key Operational Metrics")
    container = st.container()
    with container:
        containera= st.container()
        with containera:
            get_analytics_metrics(metrics_operational)
        st.divider()
        set_blue_header("Charts")
        containerb = st.container()
        with containerb:
            ccb = st.columns(2)
            with ccb[0]:
                chart_container1()
            with ccb[1]:
                chart_container2()
        st.divider()
        containerc = st.container()
        with containerc:
            ccc = st.columns(2)
            with ccc[0]:
                chart_container1()
            with ccc[1]: 
                chart_container2()
        st.divider()

def get_selected_tab_financial():
    set_blue_header("Key Financial Metrics")
    container = st.container()
    with container:
        containera= st.container()
        with containera:
            get_analytics_metrics(metrics_financial)
        st.divider()
        set_blue_header("Charts")
        containerb = st.container()
        with containerb:
            ccb = st.columns(2)
            with ccb[0]:
                chart_container1()
            with ccb[1]:
                chart_container2()
        st.divider()
        containerc = st.container()
        with containerc:
            ccc = st.columns(2)
            with ccc[0]:
                chart_container1()
            with ccc[1]: 
                chart_container2()
        st.divider()

def get_analytics_tabs():
    tab_selected_id = stx.tab_bar(data=tablist, default="11")
    if tab_selected_id=="11":
        get_selected_tab_streaming()
    elif tab_selected_id=="12":
        get_selected_tab_financial()
    elif tab_selected_id=="13":
        get_selected_tab_operational()
    else:
        get_selected_tab_streaming()
